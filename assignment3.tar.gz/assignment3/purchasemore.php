<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Add new customer</title>
</head>
<body>
<?php
include 'connectdb.php';
?>

<h2> Quantity? </h2>
<form action="getpurchasemore.php" method="post">
noofpurchase : <input type="int" name ="noofpurchase"><br>
<input type="submit" value = "Add new confirm">
</form>
<?php
mysqli_close($connection);
?>
</body>
</html>


