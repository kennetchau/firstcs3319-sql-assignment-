<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Customers purchase</title>
</head>
<body>
<?php
include 'connectdb.php';
?>
<h1>Total sales in quantity and revenue:</h1>
<ol>
<?php
   $product= $_POST["ProductID"];
   $query3 = 'SELECT description FROM Products WHERE ProductID = "' . $product . '"';
   $result2=mysqli_query($connection,$query3);
   if(!$result2){
	die("database query3 failed.");
   }
   $row3 = mysqli_fetch_assoc($result2);
   echo "description: ";
   echo $row3["description"];
   echo "<br>";
   $query = 'SELECT sum(noofpurchase) FROM PurchasingInfo WHERE ProductID= "' . $product . '"';
   $result=mysqli_query($connection,$query);
    if (!$result) {
         die("database query2 failed.");
     }
    while ($row=mysqli_fetch_assoc($result)) {
        echo "no of purchase: ";
        echo $row["sum(noofpurchase)"];
	echo "<br>";
	$noofpurchase = intval($row["sum(noofpurchase)"]);
     }
   $query1 = 'SELECT cost FROM Products WHERE ProductID = "' . $product . '"';
   $result1=mysqli_query($connection,$query1);
    if (!$result1) {
         die("database query2 failed.");
     }
   $row1 = mysqli_fetch_assoc($result1);
   $totalsum = intval($row1["cost"])*$noofpurchase;
   echo "total revenue: ";
    echo "$totalsum";

     mysqli_free_result($result);
     mysqli_free_result($result1);
?>
</ol>
<?php
   mysqli_close($connection);
?>
</body>
</html>


