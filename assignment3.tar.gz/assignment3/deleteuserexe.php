
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Delete user</title>
</head>
<body>
<?php
include 'connectdb.php';
?>
<h1></h1>
<ol>
<?php
   $whichcustomer= $_POST["Customersname"];
   $query = 'DELETE FROM Customers WHERE CustomersID = "' . $whichcustomer . '"';
   $result=mysqli_query($connection,$query);
    if (!$result) {
         die("database query2 failed.");
     }
   echo "Customer deleted";
?>
</ol>
<?php
   mysqli_close($connection);
?>
</body>
</html>


