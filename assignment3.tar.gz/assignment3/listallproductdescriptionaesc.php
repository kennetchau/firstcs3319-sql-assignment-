<html>
<head>
<meta charset="utf-8">
<title>getting data</title>
</head>
<body>
<h1>All Products</h1>
<h2>All Products we have in database order in descripition in asec</h2>
<?php
include 'connectdb.php';
?>
<?php
include 'findallproductdescriptionaesc.php';
?>
<?php
mysqli_close($connection);
?>
<ol>
</ol>
</body>
</html>











