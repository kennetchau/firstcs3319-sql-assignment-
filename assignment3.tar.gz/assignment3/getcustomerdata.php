<?php
$query = "SELECT * FROM Customers GROUP BY lastname";
$result = mysqli_query($connection,$query);
if (!$result) {
    die("databases query failed.");
}
echo "The following information is at the format, Customers ID, Firstname, lastname,city";
echo "Click the button beside to select a customer for more detailed view.";
echo "<br>";
while ($row = mysqli_fetch_assoc($result)) {
	echo '<input type="radio" name="Customersname" value="';
        echo $row["CustomersID"];
        echo '">' . $row["CustomerID"] ." ". $row["firstname"] . " " . $row["lastname"] . " " . $row["city"] . "<br>";
}
mysqli_free_result($result);
?>
