<?php
$query = "SELECT * FROM Products WHERE ProductID IN (SELECT ProductID FROM PurchasingInfo)";
$result = mysqli_query($connection,$query);
if (!$result) {
    die("databases query failed.");
}
echo "Click the button beside to select a product.";
echo "<br>";
while ($row = mysqli_fetch_assoc($result)) {


        echo '<input type="radio" name="ProductID" value="';
        echo $row["ProductID"];
        echo '">' . $row["description"] ." <br>" ;
}
mysqli_free_result($result);
?>

