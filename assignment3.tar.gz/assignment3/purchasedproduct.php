<html>
<head>
<meta charset="utf-8">
<title>getting data</title>
</head>
<body>
<h1>Purchased product</h1>
<h2>Products that been purchased</h2>
<?php
include 'connectdb.php';
?>
<form action = "getpurchasedproduct.php"" method = "post">
<?php
include 'getpurchaseproductdetail.php';
?>
<input type = "submit" value  = "get product purchase">
</form>
<?php
mysqli_close($connection);
?>
<ol>
</ol>
</body>
</html>

