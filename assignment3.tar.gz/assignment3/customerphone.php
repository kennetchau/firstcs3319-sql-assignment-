
<html>
<head>
<meta charset="utf-8">
<title>getting data</title>
</head>
<body>
<h1>Customers data</h1>
<h2>Our Customers</h2>
<?php
include 'connectdb.php';
?>
<form action = "updatecustomerphone.php"" method = "post">
<?php
include 'getcustomerdata.php';
?>
<input type = "submit" value  = "update phone">
</form>
<?php
mysqli_close($connection);
?>
<ol>
</ol>
</body>
</html>



