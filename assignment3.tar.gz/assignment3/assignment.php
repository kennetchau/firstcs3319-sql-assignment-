<html>
<head>
<meta charset="utf-8">
<title>Assignment 3</title>
</head>
<body>
<h1>CS 3319 Assignment 3</h1>
<h2></h2>
<?php 
include 'connectdb.php';
?>
<form action = "customerdata.php">
<input type = "submit" value="customer data">
</form>
<form action = "listallproduct.php">
<input type = "submit" value="list all product">
</form>
<form action = "newpurchase.php">
<input type = "submit" value="new purchase">
</form>
<form action = "newcustomer.php">
<input type = "submit" value="new customers">
</form>
<form action = "customerphone.php">
<input type = "submit" value="updatephone">
</form>
<form action = "deleteuser.php">
<input type = "submit" value="deleteuser">
</form>
<form action = "purchasemore.php">
<input type = "submit" value="purchase more">
</form>
<form action = "neverpurchase.php">
<input type = "submit" value="neverpurchase">
</form>
<form action = "purchasedproduct.php">
<input type = "submit" value="purchased product">
</form>




<ol>
</ol>
</body>
</html>
