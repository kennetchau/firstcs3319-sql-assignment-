<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>All purchase in database</title>
</head>
<body>
<?php
   include 'connectdb.php';
?>
<h1>purchase larger than given quantity </h1>
<ol>
<?php
   $noofpurchase = $_POST["noofpurchase"];
   $query = 'SELECT firstname, lastname, description, noofpurchase FROM Customers, Products, PurchasingInfo WHERE Customers.CustomersID = PurchasingInfo.CustomersID AND Products.ProductID = PurchasingInfo.ProductID AND PurchasingInfo.noofpurchase > "' . $noofpurchase . '"';
   $result=mysqli_query($connection,$query);
   if(!$result){
	die("database query failed.");
   }
   while($row=mysqli_fetch_assoc($result)){
   	echo $row["firstname"];
	echo " ";
	echo $row["lastname"];
	echo " ";
	echo $row["noofpurchase"];
	echo " ";
	echo $row["description"];
	echo "<br>";
   }
?>
</ol>
</body>
</html>


