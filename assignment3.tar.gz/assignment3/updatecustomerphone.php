
<html>
<head>
<meta charset="utf-8">
<title>getting data</title>
</head>
<body>
<h1>Customers data</h1>
<h2>Our Customers phone</h2>
<?php
include 'connectdb.php';
?>

<?php
   $CustomerID = $_POST["Customersname"];
   $query1 = 'SELECT * FROM Customers WHERE CustomersID = "' . $CustomerID . '"';
   $result = mysqli_query($connection,$query1);
   if(!$result){
        die("database max query failed.");
   }
   while ($row=mysqli_fetch_assoc($result)){
echo "phone number:";
 echo $row["phone"];
}
?>

<form action = "updatecustomerphoneno.php" method = "post">
<input type="hidden" " name="CustomerID" value="<?php echo $_POST["Customersname"]?>">
new phone number: <input type = "int" name = "newphonenumber"><br>
<input type = "submit" value = "confirm">
</form>

<?php
mysqli_close($connection);
?>
<ol>
</ol>
</body>
</html>



