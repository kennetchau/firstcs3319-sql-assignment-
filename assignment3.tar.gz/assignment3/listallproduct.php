<html>
<head>
<meta charset="utf-8">
<title>getting data</title>

</head>
<body>
<h1>All Products</h1>
<h2>Please click the button with respective order</h2>
<form action = "listallproductcostaesc.php">
<input type="submit" value="cost asec" >
</form> 
<form action = "listallproductcostdesc.php">
<input type="submit" value="cost dsec" >
</form>
<form action = "listallproductdescriptionaesc.php">
<input type="submit" value="description asec" >
</form>
<form action = "listallproductdescriptiondesc.php">
<input type="submit" value="description dsec" >
</form>

<ol>
</ol>
</body>
</html>












