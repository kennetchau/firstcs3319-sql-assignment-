
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>All purchase in database</title>
</head>
<body>
<?php
   include 'connectdb.php';
?>
<h1>All purchase: </h1>
<ol>
<?php
   $firstname = $_POST["firstname"];
   $lastname = $_POST["lastname"];
   $city = $_POST["city"];
   $phone = $_POST["phone"];
   $query1 = 'select max(CustomersID) as maxid from Customers';
   $result = mysqli_query($connection,$query1);
   if(!$result){
	die("database max query failed.");
   }
   $row = mysqli_fetch_assoc($result);
   $newkey = intval($row["maxid"])+1;
   $CustomerID = (string)$newkey;
   $query = 'INSERT INTO Customers VALUES("' . $CustomerID . '" , "' . $firstname  . '" , "' . $lastname . '" , "' . $city . '" , "' . $phone . '")';
   if (!mysqli_query($connection, $query)) {
        die("Error: insert failed" . mysqli_error($connection));
    }
   echo "Purchase was added";
   mysqli_close($connection);
?>
</ol>
</body>
</html>





