
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>All purchase in database</title>
</head>
<body>
<?php
   include 'connectdb.php';
?>
<h1>Phone update </h1>
<ol>
<?php
   $nphoneno = $_POST["newphonenumber"];
   $CustomerID = $_POST["CustomerID"];
   $query = 'UPDATE Customers SET phone = "' . $nphoneno . '" WHERE CustomersID = "' . $CustomerID . '"';   
   if (!mysqli_query($connection,$query)){
	die("Error: update failed". mysqli_error($connection));
   }
   echo "Successful update";
   mysqli_close($connection);
?>
</ol>
</body>
</html>


