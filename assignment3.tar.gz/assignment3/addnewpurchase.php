<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>All purchase in database</title>
</head>
<body>
<?php
   include 'connectdb.php';
?>
<h1>All purchase: </h1>
<ol>
<?php
   $CustomersID = $_POST["CustomerID"];
   $ProductID = $_POST["ProductID"];
   $noofpurchase =$_POST["noofpurchase"];
   $query = 'INSERT INTO PurchasingInfo VALUES("' . $CustomersID . '","' . $ProductID . '","' . $noofpurchase . '")';
   if (!mysqli_query($connection, $query)) {
        die("Error: insert failed" . mysqli_error($connection));
    }
   echo "Purchase was added";
   mysqli_close($connection);
?>
</ol>
</body>
</html>
