<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>addpurchase</title>
</head>
<body>
<?php
include 'connectdb.php';
?>

<h2> Add a new purchase:</h2>
<form action="addnewpurchase.php" method="post">
CustomerID: <input type="int" name="CustomerID"><br>
ProductID: <input type="int" name ="ProductID"><br>
no of purchase: <input type="int" name = "noofpurchase"><br>
<input type="submit" value = "Add new purchase">
</form>
<?php
mysqli_close($connection);
?>
</body>
</html>
