<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Add new customer</title>
</head>
<body>
<?php
include 'connectdb.php';
?>

<h2> Add a new customer:</h2>
<form action="addnewcustomer.php" method="post">
firstname : <input type="text" name ="firstname"><br>
lastname: <input type="text" name = "lastname"><br>
city: <input type = "text" name = "city"><br>
phone: <input type = "int" name = "phone"><br>
<input type="submit" value = "Add new customer">
</form>
<?php
mysqli_close($connection);
?>
</body>
</html>


