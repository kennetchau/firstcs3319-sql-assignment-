<?php
$query = "SELECT * FROM Products GROUP BY description desc";
$result = mysqli_query($connection,$query);
if (!$result) {
	die("databases query failed.");
}
echo "<br>";
while ($row = mysqli_fetch_assoc($result)){
	echo $row["ProductID"] . " " . $row["description"] . " " . $row["cost"] . " " . $row["nofiteminhand"] . "<br>";;
}
mysqli_free_result($result);
?>
