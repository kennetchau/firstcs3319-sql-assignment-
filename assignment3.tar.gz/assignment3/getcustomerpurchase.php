<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Customers purchase</title>
</head>
<body>
<?php
include 'connectdb.php';
?>
<h1>Here are the customers purchase:</h1>
<ol>
<?php
   $whichcustomer= $_POST["Customersname"];
   $query = 'SELECT * FROM Products, Customers, PurchasingInfo WHERE Customers.CustomersID=PurchasingInfo.CustomersID AND PurchasingInfo.ProductID = Products.ProductID  AND Customers.CustomersID="' .$whichcustomer . '"';
   $result=mysqli_query($connection,$query);
    if (!$result) {
         die("database query2 failed.");
     }
    while ($row=mysqli_fetch_assoc($result)) {
        echo '<li>';
        echo $row["description"];
     }
     mysqli_free_result($result);
?>
</ol>
<?php
   mysqli_close($connection);
?>
</body>
</html>
